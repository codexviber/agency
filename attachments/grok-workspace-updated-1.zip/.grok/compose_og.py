#!/usr/bin/env python3
"""Composite the official CodeXViber mark and exact lockup onto the brand plate."""
from PIL import Image, ImageDraw, ImageFilter, ImageFont
import numpy as np

W, H = 1200, 630
bg = Image.open("/workspace/.grok/og-bg.jpg").convert("RGBA")
assert bg.size == (W, H), bg.size

yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
cx, cy = W * 0.50, H * 0.50
rx, ry = 460.0, 250.0
n = ((xx - cx) / rx) ** 2 + ((yy - cy) / ry) ** 2
alpha = np.clip(1.0 - n, 0, 1) ** 0.72
layer = np.zeros((H, W, 4), dtype=np.uint8)
layer[..., 0] = 5
layer[..., 1] = 7
layer[..., 2] = 11
layer[..., 3] = (alpha * 168).astype(np.uint8)
canvas = Image.alpha_composite(bg, Image.fromarray(layer, "RGBA"))

logo = Image.open("/workspace/public/brand/logo.png").convert("RGBA")
logo = logo.crop(logo.getbbox())
target_h = 112
logo = logo.resize(
    (max(1, round(logo.width * target_h / logo.height)), target_h),
    Image.Resampling.LANCZOS,
)

bold = ImageFont.truetype(
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf", 122
)
reg = ImageFont.truetype(
    "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf", 26
)

TITLE = "CodeXViber"
TRACK = -4
WHITE = (248, 250, 252, 255)
BLUE = (22, 140, 255, 255)
RED = (237, 36, 56, 255)
MUTED = (210, 220, 230, 255)


def glyph_w(font, ch):
    b = font.getbbox(ch)
    return b[2] - b[0]


def tracked_width(font, text, tracking):
    if not text:
        return 0
    return sum(glyph_w(font, ch) for ch in text) + tracking * (len(text) - 1)


def draw_tracked(base, font, text, x, y, tracking, fill, shadow=True):
    """y is the baseline. Returns the right edge."""
    cursor = x
    if shadow:
        sh = Image.new("RGBA", base.size, (0, 0, 0, 0))
        sd = ImageDraw.Draw(sh)
        c = x
        for i, ch in enumerate(text):
            sd.text((c + 2, y + 3), ch, font=font, fill=(0, 0, 0, 140), anchor="ls")
            c += glyph_w(font, ch) + (tracking if i < len(text) - 1 else 0)
        sh = sh.filter(ImageFilter.GaussianBlur(6))
        base.alpha_composite(sh)
    d = ImageDraw.Draw(base)
    for i, ch in enumerate(text):
        color = BLUE if ch == "X" else fill
        d.text((cursor, y), ch, font=font, fill=color, anchor="ls")
        cursor += glyph_w(font, ch) + (tracking if i < len(text) - 1 else 0)
    return cursor


title_w = tracked_width(bold, TITLE, TRACK)
ascent, descent = bold.getmetrics()
title_h = ascent + descent

TAG = "Ideas  →  Code  →  Impact"
tag_w = tracked_width(reg, TAG, 1)
tag_asc, tag_desc = reg.getmetrics()
tag_h = tag_asc + tag_desc

gap_logo = 10
gap_rule = 18
rule_h = 4
gap_tag = 16
block = logo.height + gap_logo + title_h + gap_rule + rule_h + gap_tag + tag_h
top = (H - block) // 2

# logo
lx = (W - logo.width) // 2
ly = top
canvas.alpha_composite(logo, (lx, ly))

# title baseline
title_baseline = ly + logo.height + gap_logo + ascent
tx = (W - title_w) // 2
draw_tracked(canvas, bold, TITLE, tx, title_baseline, TRACK, WHITE)

# red rule
rule_w = 64
rule_y = title_baseline + descent + gap_rule
rd = ImageDraw.Draw(canvas)
rd.rounded_rectangle(
    ((W - rule_w) // 2, rule_y, (W + rule_w) // 2, rule_y + rule_h),
    radius=2,
    fill=RED,
)

# tagline
tag_baseline = rule_y + rule_h + gap_tag + tag_asc
tag_x = (W - tag_w) // 2
draw_tracked(canvas, reg, TAG, tag_x, tag_baseline, 1, MUTED, shadow=False)

out = canvas.convert("RGB")
out.save("/workspace/.grok/og-preview.png", "PNG")
print("title_w", title_w, "tag_w", tag_w, "block", block, "top", top)
print("logo", logo.size, "at", lx, ly)
print("title box y", title_baseline - ascent, "to", title_baseline + descent)
print("tag box y", tag_baseline - tag_asc, "to", tag_baseline + tag_desc)
